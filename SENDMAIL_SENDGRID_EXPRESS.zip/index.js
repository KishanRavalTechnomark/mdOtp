
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const { sendEmail } = require('./mailer');

const app = express();
app.use(bodyParser.json());

app.post('/send-email', async (req, res) => {
  const { to, subject, text, html } = req.body;
  if (!to || !subject) {
    return res.status(400).send('To and subject fields are required');
  }
  try {
    await sendEmail(to, subject, text, html);
    res.status(200).send('Email sent successfully');
  } catch (error) {
    res.status(500).send('Error sending email');
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
