require('dotenv').config();
const sgMail = require('@sendgrid/mail');

const SENDGRID_API_KEY = process.env.SENDGRID_API_KEY;
sgMail.setApiKey(SENDGRID_API_KEY);

const sendEmail = async (to, subject, text, html) => {
  const msg = {
    to: to,
    from: 'info@franchoiceworld.com',
    subject: subject,
    text: text,
    html: html,
  };
  try {
    await sgMail.send(msg);
    console.log('Email sent successfully');
  } catch (error) {
    console.error('Error sending email:', error.response.body);
  }
};

module.exports = { sendEmail };
