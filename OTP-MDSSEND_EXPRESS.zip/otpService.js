const axios = require("axios");

const USERNAME = "GYAATA";
const API_KEY = "OhPITiHlmb6P";
const SENDER_ID = "FRANWD";
const ROUTE = "TRANS";

const sendOtp = async (phoneNumber, otp) => {
  try {
    const textMessage = `Your OTP for Franchoice World registration is ${otp}. Enter this code to verify your mobile number.`;
    const response = await axios.get("https://mdssend.in/api.php", {
      params: {
        username: USERNAME,
        apikey: API_KEY,
        senderid: SENDER_ID,
        route: ROUTE,
        mobile: phoneNumber,
        text: textMessage,
      },
    });
    return response.data;
  } catch (error) {
    console.error("Error sending OTP:", error);
    throw error;
  }
};

const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000);
};

module.exports = { sendOtp, generateOTP };
