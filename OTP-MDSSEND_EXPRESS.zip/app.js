const express = require("express");
const { sendOtp, generateOTP } = require("./otpService");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.post("/sendOtp", async (req, res) => {
  try {
    const { phoneNumber } = req.body;
    if (!phoneNumber) {
      return res.status(400).json({ error: "Phone number is required" });
    }
    const otp = generateOTP();
    const response = await sendOtp(phoneNumber, otp);
    res.status(200).json({ message: "OTP sent successfully", response });
  } catch (error) {
    res.status(500).json({ error: "Failed to send OTP", details: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
